#include <string>

#include "controller/main_controller.h"

// Entry point. By default (no arguments) the simulator runs fully
// interactively: the user is prompted for every task and simulation
// parameter at the console, with no hardcoded or predefined task data.
//
// Passing two file paths (simulation config, task config) instead runs
// the file-based path, kept for automation/scripted/regression use --
// it is not the default and is never used unless explicitly requested.
int main(int argc, char* argv[]) {
  if (argc >= 3) {
    const std::string simulation_config_path = argv[1];
    const std::string tasks_config_path = argv[2];
    automotive_scheduler::MainController controller(simulation_config_path,
                                                      tasks_config_path);
    return controller.Run() ? 0 : 1;
  }

  automotive_scheduler::MainController controller("", "");
  return controller.RunInteractive() ? 0 : 1;
}
