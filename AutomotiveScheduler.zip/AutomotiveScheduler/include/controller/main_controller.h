#ifndef AUTOMOTIVE_SCHEDULER_CONTROLLER_MAIN_CONTROLLER_H_
#define AUTOMOTIVE_SCHEDULER_CONTROLLER_MAIN_CONTROLLER_H_

#include <memory>
#include <string>

#include "configuration/configuration_manager.h"
#include "configuration/simulation_config.h"
#include "scheduler/scheduling_algorithm.h"
#include "task/task_manager.h"

namespace automotive_scheduler {

// Orchestrates the full simulation workflow described in Section 6 of the
// requirements specification: load/validate configuration, initialize
// the scheduler, run the simulation loop, and generate/display the
// performance report.
class MainController {
 public:
  MainController(std::string simulation_config_path,
                 std::string tasks_config_path);

  // Runs the end-to-end simulation using file-based configuration
  // (config/simulation_config.txt + config/tasks_config.txt or paths
  // supplied via the constructor). Kept for automation/scripted use.
  // Returns true on success; on failure (e.g. invalid configuration)
  // prints an error and returns false.
  bool Run();

  // Runs the end-to-end simulation using configuration collected
  // entirely from interactive console input (ConsoleInputManager). No
  // task or simulation value is hardcoded or read from a file in this
  // path. Returns true on success.
  bool RunInteractive();

 private:
  std::unique_ptr<SchedulingAlgorithm> CreateAlgorithm(
      SchedulingAlgorithmType type) const;

  // Shared simulation core used by both Run() and RunInteractive() once
  // a validated SimulationConfig is available, so the two entry points
  // never duplicate the scheduling/execution/reporting logic.
  bool RunSimulationLoop(const SimulationConfig& config);

  std::string simulation_config_path_;
  std::string tasks_config_path_;
  SimulationConfig config_;
  TaskManager task_manager_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_CONTROLLER_MAIN_CONTROLLER_H_
