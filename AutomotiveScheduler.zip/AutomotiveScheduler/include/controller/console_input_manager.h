#ifndef AUTOMOTIVE_SCHEDULER_CONTROLLER_CONSOLE_INPUT_MANAGER_H_
#define AUTOMOTIVE_SCHEDULER_CONTROLLER_CONSOLE_INPUT_MANAGER_H_

#include <string>

#include "configuration/simulation_config.h"
#include "task/task.h"

namespace automotive_scheduler {

// Gathers a complete SimulationConfig entirely from interactive console
// input. No task or simulation value is ever hardcoded here -- every
// field the scheduler acts on (task count, id, name, type, execution
// time, period, deadline, priority, scheduling policy, and simulation
// duration) is typed in by the user at runtime. Console I/O is kept
// separate from the pure validation rules in input_validation.h so the
// latter can be unit tested without simulating stdin.
class ConsoleInputManager {
 public:
  ConsoleInputManager() = default;

  // Runs the full interactive configuration flow and returns the
  // accepted configuration. Loops on invalid input at every step, shows
  // a professional summary of exactly what was entered, and lets the
  // user restart configuration from scratch if they decline the final
  // "Start simulation? (Y/N)" confirmation.
  SimulationConfig CollectConfiguration() const;

 private:
  int PromptForPositiveInt(const std::string& prompt_label) const;
  std::string PromptForNonEmptyString(const std::string& prompt_label) const;

  int PromptForTaskCount() const;
  SchedulingAlgorithmType PromptForSchedulingAlgorithm() const;
  int PromptForSimulationDuration() const;
  Task PromptForTaskDefinition(int task_number,
                                SchedulingAlgorithmType algorithm) const;

  void DisplayConfigurationSummary(const SimulationConfig& config) const;
  bool ConfirmStart() const;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_CONTROLLER_CONSOLE_INPUT_MANAGER_H_
