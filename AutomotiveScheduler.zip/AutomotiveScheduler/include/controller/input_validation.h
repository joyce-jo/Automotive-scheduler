#ifndef AUTOMOTIVE_SCHEDULER_CONTROLLER_INPUT_VALIDATION_H_
#define AUTOMOTIVE_SCHEDULER_CONTROLLER_INPUT_VALIDATION_H_

#include <string>

namespace automotive_scheduler {

// Pure, I/O-free validation helpers used by ConsoleInputManager. Kept
// separate from console interaction (std::cin/std::cout) so they can be
// unit tested directly without simulating stdin.

// Parses text as a strictly positive integer. Returns false (leaving
// *out_value untouched) if text is not a valid integer, has trailing
// non-numeric characters, or is not greater than zero.
bool TryParsePositiveInt(const std::string& text, int* out_value);

// Returns true if text contains at least one non-whitespace character.
bool IsNonEmptyAfterTrim(const std::string& text);

// Encodes the logical scheduling constraint that a task's execution
// time must not exceed its deadline (matches the rule already enforced
// by ConfigurationManager::ValidateConfig for file-based configuration).
bool IsExecutionTimeWithinDeadline(int execution_time_ms, int deadline_ms);

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_CONTROLLER_INPUT_VALIDATION_H_
