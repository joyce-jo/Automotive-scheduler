#ifndef AUTOMOTIVE_SCHEDULER_TASK_TASK_MANAGER_H_
#define AUTOMOTIVE_SCHEDULER_TASK_TASK_MANAGER_H_

#include <cstddef>
#include <memory>
#include <vector>

#include "task/task.h"
#include "task/task_instance.h"

namespace automotive_scheduler {

// Owns the set of Task definitions configured for a simulation run and is
// responsible for releasing new TaskInstance objects as the virtual clock
// advances.
class TaskManager {
 public:
  TaskManager() = default;

  void AddTask(const Task& task);
  const std::vector<Task>& tasks() const { return tasks_; }

  // Derives RMS priorities for every managed task (shorter period implies
  // higher priority) and stores the result on each Task.
  void DeriveRateMonotonicPriorities();

  // Returns newly-released task instances at the given point in simulated
  // time (a task is released whenever current_time_ms is an integer
  // multiple of its period).
  std::vector<std::shared_ptr<TaskInstance>> ReleaseDueInstances(
      int current_time_ms);

 private:
  std::vector<Task> tasks_;
  // Tracks how many instances of each task (by index into tasks_) have
  // already been released, so instance numbers can be computed without
  // hardcoding simulation-specific values.
  std::vector<int> released_instance_counts_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_TASK_TASK_MANAGER_H_
