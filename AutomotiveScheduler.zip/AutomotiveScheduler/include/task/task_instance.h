#ifndef AUTOMOTIVE_SCHEDULER_TASK_TASK_INSTANCE_H_
#define AUTOMOTIVE_SCHEDULER_TASK_TASK_INSTANCE_H_

#include <string>

namespace automotive_scheduler {

// Lifecycle states a task instance moves through, matching Figure 3 of
// the requirements specification (Created -> Ready -> Running ->
// Completed, with Deadline Missed as an alternate terminal state, and
// preemption returning Running to Ready).
enum class TaskState {
  kCreated,
  kReady,
  kRunning,
  kCompleted,
  kDeadlineMissed
};

// Represents a single job (instance) released by a periodic Task
// definition. Holds all the mutable, per-release state that the scheduler
// tracks while the simulation progresses.
class TaskInstance {
 public:
  TaskInstance(std::string task_id, int instance_number, int release_time_ms,
               int execution_time_ms, int absolute_deadline_ms,
               int priority);

  const std::string& task_id() const { return task_id_; }
  int instance_number() const { return instance_number_; }
  int release_time_ms() const { return release_time_ms_; }
  int absolute_deadline_ms() const { return absolute_deadline_ms_; }
  int priority() const { return priority_; }

  int remaining_execution_time_ms() const {
    return remaining_execution_time_ms_;
  }
  void ConsumeExecutionTime(int elapsed_ms);

  TaskState state() const { return state_; }
  void set_state(TaskState state) { state_ = state; }

  int completion_time_ms() const { return completion_time_ms_; }
  void set_completion_time_ms(int time_ms) { completion_time_ms_ = time_ms; }

  bool has_started_running() const { return first_run_time_ms_ >= 0; }
  void RecordFirstRun(int time_ms);

  int preemption_count() const { return preemption_count_; }
  void IncrementPreemptionCount() { ++preemption_count_; }

  int waiting_time_ms() const { return waiting_time_ms_; }
  void AccumulateWaitingTime(int elapsed_ms) {
    waiting_time_ms_ += elapsed_ms;
  }

 private:
  std::string task_id_;
  int instance_number_;
  int release_time_ms_;
  int execution_time_ms_;
  int absolute_deadline_ms_;
  int priority_;

  int remaining_execution_time_ms_;
  TaskState state_;
  int completion_time_ms_;
  int first_run_time_ms_;
  int preemption_count_;
  int waiting_time_ms_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_TASK_TASK_INSTANCE_H_
