#ifndef AUTOMOTIVE_SCHEDULER_TASK_TASK_H_
#define AUTOMOTIVE_SCHEDULER_TASK_TASK_H_

#include <string>

namespace automotive_scheduler {

// Enumerates the scheduling algorithms supported by the simulator.
enum class SchedulingAlgorithmType {
  kFixedPriority,
  kRateMonotonic
};

// Enumerates the automotive task categories a user can assign to a task
// at configuration time (display/classification only -- it does not
// affect scheduling behavior).
enum class TaskType {
  kSensor,
  kControl,
  kSafety
};

// Renders a TaskType as a human-readable label for console/report output.
inline std::string ToString(TaskType type) {
  switch (type) {
    case TaskType::kSensor:
      return "Sensor";
    case TaskType::kControl:
      return "Control";
    case TaskType::kSafety:
      return "Safety";
  }
  return "Unknown";
}

// Represents the static definition (template) of a real-time task as
// configured by the user. A Task may spawn multiple TaskInstance objects
// over the course of a simulation if it is periodic. Every field
// originates from user-provided configuration (console input or a
// configuration file) -- none of it is ever hardcoded.
class Task {
 public:
  // task_name and task_type are optional (default to an empty name and
  // TaskType::kControl) so existing call sites built from file-based
  // configuration, which does not carry these display-only fields,
  // continue to compile unchanged.
  Task(std::string task_id, int period_ms, int execution_time_ms,
       int deadline_ms, int configured_priority,
       std::string task_name = "",
       TaskType task_type = TaskType::kControl);

  const std::string& task_id() const { return task_id_; }
  const std::string& task_name() const { return task_name_; }
  TaskType task_type() const { return task_type_; }
  int period_ms() const { return period_ms_; }
  int execution_time_ms() const { return execution_time_ms_; }
  int deadline_ms() const { return deadline_ms_; }
  int configured_priority() const { return configured_priority_; }

  // The priority actually used by the scheduler. For Fixed Priority
  // scheduling this equals configured_priority(); for RMS it is derived
  // from period_ms() (shorter period -> higher priority) and set via
  // set_effective_priority().
  int effective_priority() const { return effective_priority_; }
  void set_effective_priority(int priority) {
    effective_priority_ = priority;
  }

 private:
  std::string task_id_;
  std::string task_name_;
  TaskType task_type_;
  int period_ms_;
  int execution_time_ms_;
  int deadline_ms_;
  int configured_priority_;
  int effective_priority_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_TASK_TASK_H_
