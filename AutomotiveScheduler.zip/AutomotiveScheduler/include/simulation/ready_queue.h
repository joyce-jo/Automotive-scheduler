#ifndef AUTOMOTIVE_SCHEDULER_SIMULATION_READY_QUEUE_H_
#define AUTOMOTIVE_SCHEDULER_SIMULATION_READY_QUEUE_H_

#include <memory>
#include <vector>

#include "task/task_instance.h"

namespace automotive_scheduler {

// Maintains the collection of task instances that are eligible for
// execution (released, but not yet completed or deadline-missed) at the
// current virtual time (FR-11).
class ReadyQueue {
 public:
  ReadyQueue() = default;

  void Insert(const std::shared_ptr<TaskInstance>& instance);

  // Removes instances that have reached a terminal state (Completed or
  // DeadlineMissed) from the active queue.
  void RemoveFinishedInstances();

  const std::vector<std::shared_ptr<TaskInstance>>& instances() const {
    return instances_;
  }

  bool IsEmpty() const { return instances_.empty(); }

 private:
  std::vector<std::shared_ptr<TaskInstance>> instances_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SIMULATION_READY_QUEUE_H_
