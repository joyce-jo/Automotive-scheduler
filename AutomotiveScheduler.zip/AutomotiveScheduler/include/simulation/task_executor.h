#ifndef AUTOMOTIVE_SCHEDULER_SIMULATION_TASK_EXECUTOR_H_
#define AUTOMOTIVE_SCHEDULER_SIMULATION_TASK_EXECUTOR_H_

#include <memory>

#include "monitoring/logger.h"
#include "task/task_instance.h"

namespace automotive_scheduler {

// Simulates the execution of the currently dispatched task instance for
// one time step, updating its progress and lifecycle state (FR-15 -
// FR-17).
class TaskExecutor {
 public:
  explicit TaskExecutor(Logger* logger);

  // Advances instance's execution by elapsed_ms. If this is the first
  // time instance has run, its first-run timestamp is recorded. If
  // execution completes, the instance transitions to
  // TaskState::kCompleted and its completion time is recorded.
  void Execute(const std::shared_ptr<TaskInstance>& instance, int elapsed_ms,
               int current_time_ms);

 private:
  Logger* logger_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SIMULATION_TASK_EXECUTOR_H_
