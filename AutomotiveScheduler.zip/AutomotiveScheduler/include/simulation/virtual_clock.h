#ifndef AUTOMOTIVE_SCHEDULER_SIMULATION_VIRTUAL_CLOCK_H_
#define AUTOMOTIVE_SCHEDULER_SIMULATION_VIRTUAL_CLOCK_H_

namespace automotive_scheduler {

// Maintains simulated time, independent of wall-clock time (FR-12 -
// FR-14). Always starts at 0 ms whenever a new simulation begins.
class VirtualClock {
 public:
  VirtualClock() : current_time_ms_(0) {}

  void Reset() { current_time_ms_ = 0; }
  void Advance(int delta_ms) { current_time_ms_ += delta_ms; }
  int current_time_ms() const { return current_time_ms_; }

 private:
  int current_time_ms_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SIMULATION_VIRTUAL_CLOCK_H_
