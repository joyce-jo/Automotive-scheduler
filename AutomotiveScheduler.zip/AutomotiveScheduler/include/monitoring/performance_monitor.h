#ifndef AUTOMOTIVE_SCHEDULER_MONITORING_PERFORMANCE_MONITOR_H_
#define AUTOMOTIVE_SCHEDULER_MONITORING_PERFORMANCE_MONITOR_H_

#include <memory>
#include <string>
#include <vector>

#include "task/task_instance.h"

namespace automotive_scheduler {

// Computes and reports the performance indicators required by FR-24 -
// FR-26 / Table 7: completed tasks, deadline misses, waiting time,
// response time, CPU utilization, preemptions, and fault information.
class PerformanceMonitor {
 public:
  PerformanceMonitor(int simulation_duration_ms,
                      std::string report_output_path);

  void RecordInstances(
      const std::vector<std::shared_ptr<TaskInstance>>& all_instances);

  // Computes metrics from the recorded instances and writes a formatted
  // report to report_output_path_. Also returns the report text so the
  // caller can display it to the user.
  std::string GenerateReport(const std::string& algorithm_name);

 private:
  int simulation_duration_ms_;
  std::string report_output_path_;
  std::vector<std::shared_ptr<TaskInstance>> all_instances_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_MONITORING_PERFORMANCE_MONITOR_H_
