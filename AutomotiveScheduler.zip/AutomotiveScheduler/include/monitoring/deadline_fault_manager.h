#ifndef AUTOMOTIVE_SCHEDULER_MONITORING_DEADLINE_FAULT_MANAGER_H_
#define AUTOMOTIVE_SCHEDULER_MONITORING_DEADLINE_FAULT_MANAGER_H_

#include <memory>
#include <vector>

#include "monitoring/logger.h"
#include "task/task_instance.h"

namespace automotive_scheduler {

// Monitors task deadlines by comparing the current virtual time against
// each active instance's pre-configured absolute deadline (FR-18 -
// FR-20, Section 10).
class DeadlineFaultManager {
 public:
  explicit DeadlineFaultManager(Logger* logger);

  // Evaluates every active instance and transitions any instance whose
  // deadline has been exceeded into TaskState::kDeadlineMissed.
  void CheckDeadlines(
      const std::vector<std::shared_ptr<TaskInstance>>& active_instances,
      int current_time_ms);

  int deadline_miss_count() const { return deadline_miss_count_; }

 private:
  Logger* logger_;
  int deadline_miss_count_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_MONITORING_DEADLINE_FAULT_MANAGER_H_
