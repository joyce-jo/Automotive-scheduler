#ifndef AUTOMOTIVE_SCHEDULER_MONITORING_LOGGER_H_
#define AUTOMOTIVE_SCHEDULER_MONITORING_LOGGER_H_

#include <fstream>
#include <string>

namespace automotive_scheduler {

// Records time-stamped scheduling events, state transitions, and fault
// occurrences to a persistent log file (FR-21 - FR-23).
class Logger {
 public:
  explicit Logger(std::string log_file_path);
  ~Logger();

  void LogEvent(int simulated_time_ms, const std::string& message);

 private:
  std::string log_file_path_;
  std::ofstream log_stream_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_MONITORING_LOGGER_H_
