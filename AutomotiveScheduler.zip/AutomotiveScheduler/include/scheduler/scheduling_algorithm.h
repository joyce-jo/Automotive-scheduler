#ifndef AUTOMOTIVE_SCHEDULER_SCHEDULER_SCHEDULING_ALGORITHM_H_
#define AUTOMOTIVE_SCHEDULER_SCHEDULER_SCHEDULING_ALGORITHM_H_

#include <memory>
#include <string>
#include <vector>

#include "task/task_instance.h"

namespace automotive_scheduler {

// Strategy interface implemented by each supported scheduling policy.
// Allows RealTimeScheduler to select the next task to run without knowing
// whether Fixed Priority or Rate Monotonic Scheduling is active (NFR-03,
// Section 9.3 Inheritance and Polymorphism).
class SchedulingAlgorithm {
 public:
  virtual ~SchedulingAlgorithm() = default;

  // Returns the highest-priority ready instance from candidates, or
  // nullptr if candidates is empty.
  virtual std::shared_ptr<TaskInstance> SelectNextInstance(
      const std::vector<std::shared_ptr<TaskInstance>>& candidates) const = 0;

  virtual std::string algorithm_name() const = 0;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SCHEDULER_SCHEDULING_ALGORITHM_H_
