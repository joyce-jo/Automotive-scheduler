#ifndef AUTOMOTIVE_SCHEDULER_SCHEDULER_REAL_TIME_SCHEDULER_H_
#define AUTOMOTIVE_SCHEDULER_SCHEDULER_REAL_TIME_SCHEDULER_H_

#include <memory>
#include <string>

#include "monitoring/logger.h"
#include "scheduler/scheduling_algorithm.h"
#include "simulation/ready_queue.h"

namespace automotive_scheduler {

// Coordinates scheduling decisions: selects the next instance to run from
// the ready queue using the active SchedulingAlgorithm strategy, and
// detects/records preemption events (FR-07 - FR-11, FR-10).
class RealTimeScheduler {
 public:
  RealTimeScheduler(std::unique_ptr<SchedulingAlgorithm> algorithm,
                     Logger* logger);

  // Selects and returns the instance that should run during the current
  // time step, updating instance states and logging any preemption that
  // occurs as a result of the decision.
  std::shared_ptr<TaskInstance> MakeSchedulingDecision(
      const ReadyQueue& ready_queue, int current_time_ms);

  const std::string& algorithm_name() const { return algorithm_name_; }

 private:
  std::unique_ptr<SchedulingAlgorithm> algorithm_;
  Logger* logger_;
  std::shared_ptr<TaskInstance> currently_running_;
  std::string algorithm_name_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SCHEDULER_REAL_TIME_SCHEDULER_H_
