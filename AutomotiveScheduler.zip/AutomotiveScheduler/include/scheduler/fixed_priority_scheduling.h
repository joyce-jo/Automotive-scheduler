#ifndef AUTOMOTIVE_SCHEDULER_SCHEDULER_FIXED_PRIORITY_SCHEDULING_H_
#define AUTOMOTIVE_SCHEDULER_SCHEDULER_FIXED_PRIORITY_SCHEDULING_H_

#include "scheduler/scheduling_algorithm.h"

namespace automotive_scheduler {

// Implements Fixed Priority Scheduling (FR-08): the ready instance with
// the highest user-configured priority is always selected. Ties are
// broken by earliest release time.
class FixedPriorityScheduling : public SchedulingAlgorithm {
 public:
  std::shared_ptr<TaskInstance> SelectNextInstance(
      const std::vector<std::shared_ptr<TaskInstance>>& candidates)
      const override;
  std::string algorithm_name() const override { return "Fixed Priority"; }
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SCHEDULER_FIXED_PRIORITY_SCHEDULING_H_
