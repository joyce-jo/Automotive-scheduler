#ifndef AUTOMOTIVE_SCHEDULER_SCHEDULER_RATE_MONOTONIC_SCHEDULING_H_
#define AUTOMOTIVE_SCHEDULER_SCHEDULER_RATE_MONOTONIC_SCHEDULING_H_

#include "scheduler/scheduling_algorithm.h"

namespace automotive_scheduler {

// Implements Rate Monotonic Scheduling (FR-09): task priorities are
// derived from period (shorter period = higher priority) by TaskManager
// before the simulation starts. At each scheduling decision the ready
// instance with the highest derived priority is selected; ties are broken
// by earliest release time.
class RateMonotonicScheduling : public SchedulingAlgorithm {
 public:
  std::shared_ptr<TaskInstance> SelectNextInstance(
      const std::vector<std::shared_ptr<TaskInstance>>& candidates)
      const override;
  std::string algorithm_name() const override { return "Rate Monotonic"; }
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_SCHEDULER_RATE_MONOTONIC_SCHEDULING_H_
