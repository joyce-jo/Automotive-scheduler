#ifndef AUTOMOTIVE_SCHEDULER_CONFIGURATION_SIMULATION_CONFIG_H_
#define AUTOMOTIVE_SCHEDULER_CONFIGURATION_SIMULATION_CONFIG_H_

#include <string>
#include <vector>

#include "task/task.h"

namespace automotive_scheduler {

// Aggregates every user-configurable simulation parameter. All values are
// populated from configuration files rather than hardcoded so that the
// simulator can be retargeted to different scenarios without recompiling.
struct SimulationConfig {
  int simulation_duration_ms = 0;
  int time_step_ms = 0;
  SchedulingAlgorithmType scheduling_algorithm =
      SchedulingAlgorithmType::kFixedPriority;
  std::string log_output_path;
  std::string report_output_path;
  std::vector<Task> tasks;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_CONFIGURATION_SIMULATION_CONFIG_H_
