#ifndef AUTOMOTIVE_SCHEDULER_CONFIGURATION_CONFIGURATION_MANAGER_H_
#define AUTOMOTIVE_SCHEDULER_CONFIGURATION_CONFIGURATION_MANAGER_H_

#include <string>

#include "configuration/simulation_config.h"

namespace automotive_scheduler {

// Loads and validates simulation and task parameters from the on-disk
// configuration files (see the config/ directory). No simulation value is
// ever hardcoded into source code; everything originates here (FR-01 -
// FR-03).
class ConfigurationManager {
 public:
  ConfigurationManager(std::string simulation_config_path,
                        std::string tasks_config_path);

  // Reads both configuration files and validates their contents. Returns
  // true on success; on failure, error_message contains a human-readable
  // description of the first problem encountered.
  bool LoadAndValidate(SimulationConfig* out_config,
                        std::string* error_message);

  // Applies the same logical validation rules used for file-based
  // configuration (FR-03) to a SimulationConfig built any other way,
  // e.g. from interactive console input via ConsoleInputManager. Kept
  // public and static so it has exactly one implementation shared by
  // every configuration source, per the project's existing design.
  static bool ValidateConfig(const SimulationConfig& config,
                              std::string* error_message);

 private:
  bool LoadSimulationSettings(SimulationConfig* out_config,
                               std::string* error_message);
  bool LoadTaskDefinitions(SimulationConfig* out_config,
                            std::string* error_message);

  std::string simulation_config_path_;
  std::string tasks_config_path_;
};

}  // namespace automotive_scheduler

#endif  // AUTOMOTIVE_SCHEDULER_CONFIGURATION_CONFIGURATION_MANAGER_H_
