#include "configuration/configuration_manager.h"

#include <fstream>
#include <sstream>

namespace automotive_scheduler {

namespace {

std::string Trim(const std::string& input) {
  const std::string whitespace = " \t\r\n";
  const std::size_t begin = input.find_first_not_of(whitespace);
  if (begin == std::string::npos) {
    return "";
  }
  const std::size_t end = input.find_last_not_of(whitespace);
  return input.substr(begin, end - begin + 1);
}

std::vector<std::string> Split(const std::string& line, char delimiter) {
  std::vector<std::string> tokens;
  std::stringstream stream(line);
  std::string token;
  while (std::getline(stream, token, delimiter)) {
    tokens.push_back(Trim(token));
  }
  return tokens;
}

bool ParseInt(const std::string& text, int* out_value) {
  try {
    std::size_t chars_consumed = 0;
    const int parsed = std::stoi(text, &chars_consumed);
    if (chars_consumed != text.size()) {
      return false;
    }
    *out_value = parsed;
    return true;
  } catch (const std::exception&) {
    return false;
  }
}

}  // namespace

ConfigurationManager::ConfigurationManager(std::string simulation_config_path,
                                            std::string tasks_config_path)
    : simulation_config_path_(std::move(simulation_config_path)),
      tasks_config_path_(std::move(tasks_config_path)) {}

bool ConfigurationManager::LoadAndValidate(SimulationConfig* out_config,
                                            std::string* error_message) {
  if (!LoadSimulationSettings(out_config, error_message)) {
    return false;
  }
  if (!LoadTaskDefinitions(out_config, error_message)) {
    return false;
  }
  return ValidateConfig(*out_config, error_message);
}

bool ConfigurationManager::LoadSimulationSettings(
    SimulationConfig* out_config, std::string* error_message) {
  std::ifstream input_file(simulation_config_path_);
  if (!input_file.is_open()) {
    *error_message = "Unable to open simulation configuration file: " +
                      simulation_config_path_;
    return false;
  }

  std::string line;
  while (std::getline(input_file, line)) {
    const std::string trimmed_line = Trim(line);
    if (trimmed_line.empty() || trimmed_line[0] == '#') {
      continue;
    }
    const std::size_t separator_pos = trimmed_line.find('=');
    if (separator_pos == std::string::npos) {
      continue;
    }
    const std::string key = Trim(trimmed_line.substr(0, separator_pos));
    const std::string value = Trim(trimmed_line.substr(separator_pos + 1));

    if (key == "simulation_duration_ms") {
      if (!ParseInt(value, &out_config->simulation_duration_ms)) {
        *error_message = "Invalid simulation_duration_ms value: " + value;
        return false;
      }
    } else if (key == "time_step_ms") {
      if (!ParseInt(value, &out_config->time_step_ms)) {
        *error_message = "Invalid time_step_ms value: " + value;
        return false;
      }
    } else if (key == "scheduling_algorithm") {
      if (value == "FIXED_PRIORITY") {
        out_config->scheduling_algorithm =
            SchedulingAlgorithmType::kFixedPriority;
      } else if (value == "RATE_MONOTONIC") {
        out_config->scheduling_algorithm =
            SchedulingAlgorithmType::kRateMonotonic;
      } else {
        *error_message = "Unknown scheduling_algorithm value: " + value;
        return false;
      }
    } else if (key == "log_output_path") {
      out_config->log_output_path = value;
    } else if (key == "report_output_path") {
      out_config->report_output_path = value;
    }
  }
  return true;
}

bool ConfigurationManager::LoadTaskDefinitions(SimulationConfig* out_config,
                                                std::string* error_message) {
  std::ifstream input_file(tasks_config_path_);
  if (!input_file.is_open()) {
    *error_message =
        "Unable to open task configuration file: " + tasks_config_path_;
    return false;
  }

  std::string line;
  bool header_skipped = false;
  while (std::getline(input_file, line)) {
    const std::string trimmed_line = Trim(line);
    if (trimmed_line.empty() || trimmed_line[0] == '#') {
      continue;
    }
    if (!header_skipped) {
      header_skipped = true;
      continue;
    }
    const std::vector<std::string> fields = Split(trimmed_line, ',');
    if (fields.size() != 5) {
      *error_message = "Malformed task definition line: " + line;
      return false;
    }

    int period_ms = 0;
    int execution_time_ms = 0;
    int deadline_ms = 0;
    int fixed_priority = 0;
    if (!ParseInt(fields[1], &period_ms) ||
        !ParseInt(fields[2], &execution_time_ms) ||
        !ParseInt(fields[3], &deadline_ms) ||
        !ParseInt(fields[4], &fixed_priority)) {
      *error_message = "Non-numeric field in task definition line: " + line;
      return false;
    }

    out_config->tasks.emplace_back(fields[0], period_ms, execution_time_ms,
                                    deadline_ms, fixed_priority);
  }
  return true;
}

bool ConfigurationManager::ValidateConfig(const SimulationConfig& config,
                                           std::string* error_message) {
  if (config.simulation_duration_ms <= 0) {
    *error_message = "simulation_duration_ms must be greater than zero.";
    return false;
  }
  if (config.time_step_ms <= 0) {
    *error_message = "time_step_ms must be greater than zero.";
    return false;
  }
  if (config.log_output_path.empty()) {
    *error_message = "log_output_path must be configured.";
    return false;
  }
  if (config.report_output_path.empty()) {
    *error_message = "report_output_path must be configured.";
    return false;
  }
  if (config.tasks.empty()) {
    *error_message = "At least one task must be configured.";
    return false;
  }
  for (const Task& task : config.tasks) {
    if (task.period_ms() <= 0) {
      *error_message = "Task '" + task.task_id() + "' has an invalid period.";
      return false;
    }
    if (task.execution_time_ms() <= 0) {
      *error_message =
          "Task '" + task.task_id() + "' has an invalid execution time.";
      return false;
    }
    if (task.execution_time_ms() > task.deadline_ms()) {
      *error_message =
          "Task '" + task.task_id() +
          "' has an execution time greater than its deadline.";
      return false;
    }
  }
  return true;
}

}  // namespace automotive_scheduler
