#include "controller/input_validation.h"

#include <cstddef>
#include <stdexcept>

namespace automotive_scheduler {

namespace {

std::string Trim(const std::string& input) {
  const std::string whitespace = " \t\r\n";
  const std::size_t begin = input.find_first_not_of(whitespace);
  if (begin == std::string::npos) {
    return "";
  }
  const std::size_t end = input.find_last_not_of(whitespace);
  return input.substr(begin, end - begin + 1);
}

}  // namespace

bool TryParsePositiveInt(const std::string& text, int* out_value) {
  const std::string trimmed = Trim(text);
  if (trimmed.empty()) {
    return false;
  }
  try {
    std::size_t chars_consumed = 0;
    const int parsed = std::stoi(trimmed, &chars_consumed);
    if (chars_consumed != trimmed.size() || parsed <= 0) {
      return false;
    }
    *out_value = parsed;
    return true;
  } catch (const std::exception&) {
    return false;
  }
}

bool IsNonEmptyAfterTrim(const std::string& text) {
  return !Trim(text).empty();
}

bool IsExecutionTimeWithinDeadline(int execution_time_ms, int deadline_ms) {
  return execution_time_ms <= deadline_ms;
}

}  // namespace automotive_scheduler
