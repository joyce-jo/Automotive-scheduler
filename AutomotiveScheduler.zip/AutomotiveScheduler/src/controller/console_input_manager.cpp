#include "controller/console_input_manager.h"

#include <iomanip>
#include <iostream>

#include "controller/input_validation.h"

namespace automotive_scheduler {

namespace {

// Genuine implementation constants (menu wiring / output destinations),
// not simulation data -- the user never types these, and they carry no
// task-specific or run-specific values.
constexpr int kDefaultTimeStepMs = 1;
const char kDefaultLogOutputPath[] = "logs/simulation_log.txt";
const char kDefaultReportOutputPath[] = "reports/performance_report.txt";

}  // namespace

int ConsoleInputManager::PromptForPositiveInt(
    const std::string& prompt_label) const {
  while (true) {
    std::cout << prompt_label;
    std::string line;
    if (!std::getline(std::cin, line)) {
      std::cin.clear();
      continue;
    }
    int value = 0;
    if (TryParsePositiveInt(line, &value)) {
      return value;
    }
    std::cout << "Invalid input. Please enter a valid numeric value "
                  "greater than 0."
              << std::endl;
  }
}

std::string ConsoleInputManager::PromptForNonEmptyString(
    const std::string& prompt_label) const {
  while (true) {
    std::cout << prompt_label;
    std::string line;
    if (!std::getline(std::cin, line)) {
      std::cin.clear();
      continue;
    }
    if (IsNonEmptyAfterTrim(line)) {
      return line;
    }
    std::cout << "Invalid input. This field cannot be empty." << std::endl;
  }
}

int ConsoleInputManager::PromptForTaskCount() const {
  return PromptForPositiveInt("Enter number of tasks: ");
}

SchedulingAlgorithmType ConsoleInputManager::PromptForSchedulingAlgorithm()
    const {
  std::cout << "\n============================================================\n";
  std::cout << "              SCHEDULING POLICY\n";
  std::cout << "============================================================\n";
  std::cout << "1. Fixed Priority Scheduling\n";
  std::cout << "2. Rate Monotonic Scheduling\n";
  while (true) {
    std::cout << "Enter choice: ";
    std::string line;
    std::getline(std::cin, line);
    if (line == "1") return SchedulingAlgorithmType::kFixedPriority;
    if (line == "2") return SchedulingAlgorithmType::kRateMonotonic;
    std::cout << "Invalid choice. Please select 1 or 2." << std::endl;
  }
}

int ConsoleInputManager::PromptForSimulationDuration() const {
  return PromptForPositiveInt("\nEnter simulation duration (ms): ");
}

Task ConsoleInputManager::PromptForTaskDefinition(
    int task_number, SchedulingAlgorithmType algorithm) const {
  std::cout << "\n---------------- Task " << task_number
            << " Configuration ----------------\n";
  const std::string task_id = PromptForNonEmptyString("Enter Task ID: ");
  const std::string task_name = PromptForNonEmptyString("Enter Task Name: ");

  TaskType task_type = TaskType::kControl;
  std::cout << "Select Task Type:\n  1. Sensor\n  2. Control\n  3. Safety\n";
  while (true) {
    std::cout << "Enter choice: ";
    std::string line;
    std::getline(std::cin, line);
    if (line == "1") {
      task_type = TaskType::kSensor;
      break;
    }
    if (line == "2") {
      task_type = TaskType::kControl;
      break;
    }
    if (line == "3") {
      task_type = TaskType::kSafety;
      break;
    }
    std::cout << "Invalid choice. Please select 1, 2, or 3." << std::endl;
  }

  int execution_time_ms = 0;
  int period_ms = 0;
  int deadline_ms = 0;
  while (true) {
    execution_time_ms = PromptForPositiveInt("Enter Execution Time (ms): ");
    period_ms = PromptForPositiveInt("Enter Period (ms): ");
    deadline_ms = PromptForPositiveInt("Enter Deadline (ms): ");
    if (!IsExecutionTimeWithinDeadline(execution_time_ms, deadline_ms)) {
      std::cout << "Invalid input. Execution time must not exceed the "
                    "deadline. Please enter this task's timing again."
                << std::endl;
      continue;
    }
    break;
  }

  int priority = 0;
  if (algorithm == SchedulingAlgorithmType::kFixedPriority) {
    priority = PromptForPositiveInt(
        "Enter Priority (higher value = more urgent): ");
  } else {
    std::cout << "(Priority will be derived automatically from period "
                  "under Rate Monotonic Scheduling.)"
              << std::endl;
  }

  return Task(task_id, period_ms, execution_time_ms, deadline_ms, priority,
              task_name, task_type);
}

void ConsoleInputManager::DisplayConfigurationSummary(
    const SimulationConfig& config) const {
  std::cout << "\n============================================================\n";
  std::cout << "                 TASK CONFIGURATION\n";
  std::cout << "============================================================\n";
  std::cout << std::left << std::setw(6) << "ID" << std::setw(18) << "Name"
            << std::setw(10) << "Type" << std::setw(7) << "Exec"
            << std::setw(8) << "Period" << std::setw(10) << "Deadline"
            << "Priority" << std::endl;
  std::cout << std::string(65, '-') << std::endl;

  for (const Task& task : config.tasks) {
    std::cout << std::left << std::setw(6) << task.task_id() << std::setw(18)
               << task.task_name() << std::setw(10) << ToString(task.task_type())
               << std::setw(7) << task.execution_time_ms() << std::setw(8)
               << task.period_ms() << std::setw(10) << task.deadline_ms()
               << (config.scheduling_algorithm ==
                           SchedulingAlgorithmType::kFixedPriority
                       ? std::to_string(task.configured_priority())
                       : std::string("(auto)"))
               << std::endl;
  }

  std::cout << std::string(65, '-') << std::endl;
  std::cout << "Scheduling Policy : "
            << (config.scheduling_algorithm ==
                        SchedulingAlgorithmType::kFixedPriority
                    ? "Fixed Priority Scheduling"
                    : "Rate Monotonic Scheduling")
            << std::endl;
  std::cout << "Simulation Time   : " << config.simulation_duration_ms
            << " ms" << std::endl;
  std::cout << "------------------------------------------------------------"
            << std::endl;
}

bool ConsoleInputManager::ConfirmStart() const {
  while (true) {
    std::cout << "\nStart simulation? (Y/N): ";
    std::string line;
    std::getline(std::cin, line);
    if (!line.empty() && (line[0] == 'Y' || line[0] == 'y')) {
      return true;
    }
    if (!line.empty() && (line[0] == 'N' || line[0] == 'n')) {
      return false;
    }
    std::cout << "Please enter Y or N." << std::endl;
  }
}

SimulationConfig ConsoleInputManager::CollectConfiguration() const {
  while (true) {
    std::cout << "============================================================\n";
    std::cout << "       PRIORITY-DRIVEN REAL-TIME SCHEDULER\n";
    std::cout << "                  AUTOMOTIVE SYSTEM\n";
    std::cout << "============================================================\n";
    std::cout << "\nConfigure Simulation\n";
    std::cout << "------------------------------------------------------------\n";

    SimulationConfig config;
    config.time_step_ms = kDefaultTimeStepMs;
    config.log_output_path = kDefaultLogOutputPath;
    config.report_output_path = kDefaultReportOutputPath;

    config.scheduling_algorithm = PromptForSchedulingAlgorithm();
    config.simulation_duration_ms = PromptForSimulationDuration();

    const int task_count = PromptForTaskCount();
    for (int task_number = 1; task_number <= task_count; ++task_number) {
      config.tasks.push_back(
          PromptForTaskDefinition(task_number, config.scheduling_algorithm));
    }

    DisplayConfigurationSummary(config);

    if (ConfirmStart()) {
      return config;
    }
    std::cout << "\nRestarting configuration...\n" << std::endl;
  }
}

}  // namespace automotive_scheduler
