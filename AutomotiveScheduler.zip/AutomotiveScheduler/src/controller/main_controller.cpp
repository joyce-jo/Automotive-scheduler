#include "controller/main_controller.h"

#include <iostream>

#include "controller/console_input_manager.h"
#include "monitoring/deadline_fault_manager.h"
#include "monitoring/logger.h"
#include "monitoring/performance_monitor.h"
#include "scheduler/fixed_priority_scheduling.h"
#include "scheduler/rate_monotonic_scheduling.h"
#include "scheduler/real_time_scheduler.h"
#include "simulation/ready_queue.h"
#include "simulation/task_executor.h"
#include "simulation/virtual_clock.h"

namespace automotive_scheduler {

MainController::MainController(std::string simulation_config_path,
                                std::string tasks_config_path)
    : simulation_config_path_(std::move(simulation_config_path)),
      tasks_config_path_(std::move(tasks_config_path)) {}

std::unique_ptr<SchedulingAlgorithm> MainController::CreateAlgorithm(
    SchedulingAlgorithmType type) const {
  if (type == SchedulingAlgorithmType::kRateMonotonic) {
    return std::make_unique<RateMonotonicScheduling>();
  }
  return std::make_unique<FixedPriorityScheduling>();
}

bool MainController::Run() {
  // 2 & 3. Load Configuration / Validate Configuration (file-based).
  ConfigurationManager configuration_manager(simulation_config_path_,
                                              tasks_config_path_);
  SimulationConfig config;
  std::string error_message;
  if (!configuration_manager.LoadAndValidate(&config, &error_message)) {
    std::cerr << "Configuration Error: " << error_message << std::endl;
    return false;
  }
  return RunSimulationLoop(config);
}

bool MainController::RunInteractive() {
  // 2 & 3. Load Configuration / Validate Configuration (console-based).
  // Every task and simulation value is collected from the user at
  // runtime -- ConsoleInputManager never invents or hardcodes a value.
  const ConsoleInputManager console_input_manager;
  const SimulationConfig config = console_input_manager.CollectConfiguration();

  std::string error_message;
  if (!ConfigurationManager::ValidateConfig(config, &error_message)) {
    std::cerr << "Configuration Error: " << error_message << std::endl;
    return false;
  }
  return RunSimulationLoop(config);
}

bool MainController::RunSimulationLoop(const SimulationConfig& config) {
  config_ = config;
  for (const Task& task : config_.tasks) {
    task_manager_.AddTask(task);
  }

  // 4. Scheduler Initialization: reset virtual clock, select algorithm.
  Logger logger(config_.log_output_path);
  VirtualClock virtual_clock;
  virtual_clock.Reset();

  if (config_.scheduling_algorithm ==
      SchedulingAlgorithmType::kRateMonotonic) {
    task_manager_.DeriveRateMonotonicPriorities();
  }

  std::unique_ptr<SchedulingAlgorithm> algorithm =
      CreateAlgorithm(config_.scheduling_algorithm);
  RealTimeScheduler scheduler(std::move(algorithm), &logger);
  DeadlineFaultManager deadline_fault_manager(&logger);
  TaskExecutor task_executor(&logger);
  ReadyQueue ready_queue;
  std::vector<std::shared_ptr<TaskInstance>> all_instances;

  logger.LogEvent(virtual_clock.current_time_ms(),
                   "Simulation started using " + scheduler.algorithm_name() +
                       " scheduling.");

  // Initial task release at t = 0 ms (FR-12, FR-13).
  for (const auto& instance :
       task_manager_.ReleaseDueInstances(virtual_clock.current_time_ms())) {
    ready_queue.Insert(instance);
    all_instances.push_back(instance);
    logger.LogEvent(virtual_clock.current_time_ms(),
                     "RELEASED: task=" + instance->task_id() + " instance=" +
                         std::to_string(instance->instance_number()));
  }

  std::cout << "\n============================================================\n";
  std::cout << "                  SCHEDULING SIMULATION\n";
  std::cout << "============================================================\n";

  // 6. Simulation Loop.
  while (virtual_clock.current_time_ms() < config_.simulation_duration_ms) {
    virtual_clock.Advance(config_.time_step_ms);
    const int current_time_ms = virtual_clock.current_time_ms();

    // 6.2 Task Release & Ready Queue Insertion.
    for (const auto& instance :
         task_manager_.ReleaseDueInstances(current_time_ms)) {
      ready_queue.Insert(instance);
      all_instances.push_back(instance);
      logger.LogEvent(current_time_ms,
                       "RELEASED: task=" + instance->task_id() +
                           " instance=" +
                           std::to_string(instance->instance_number()));
    }

    // 6.3 Scheduling Decision (priority comparison & preemption check).
    const std::shared_ptr<TaskInstance> running_instance =
        scheduler.MakeSchedulingDecision(ready_queue, current_time_ms);

    // Instances that are ready but not selected accrue waiting time for
    // this time step.
    for (const auto& instance : ready_queue.instances()) {
      const bool is_terminal =
          instance->state() == TaskState::kCompleted ||
          instance->state() == TaskState::kDeadlineMissed;
      if (!is_terminal && instance != running_instance) {
        instance->AccumulateWaitingTime(config_.time_step_ms);
      }
    }

    // 6.4 Task Execution.
    if (running_instance != nullptr) {
      task_executor.Execute(running_instance, config_.time_step_ms,
                             current_time_ms);
    }

    // 6.5 Completion & Deadline Check.
    deadline_fault_manager.CheckDeadlines(ready_queue.instances(),
                                           current_time_ms);
    ready_queue.RemoveFinishedInstances();
  }

  // 7. Generate Performance Report.
  PerformanceMonitor performance_monitor(config_.simulation_duration_ms,
                                          config_.report_output_path);
  performance_monitor.RecordInstances(all_instances);
  const std::string report =
      performance_monitor.GenerateReport(scheduler.algorithm_name());

  logger.LogEvent(virtual_clock.current_time_ms(), "Simulation ended.");

  // 8. Display Report to User. Every figure below comes from the
  // instances actually created and executed above -- nothing here is
  // fabricated or hardcoded.
  std::cout << "\n" << report << std::endl;
  std::cout << "Full log written to: " << config_.log_output_path
            << std::endl;
  std::cout << "Full report written to: " << config_.report_output_path
            << std::endl;
  return true;
}

}  // namespace automotive_scheduler
