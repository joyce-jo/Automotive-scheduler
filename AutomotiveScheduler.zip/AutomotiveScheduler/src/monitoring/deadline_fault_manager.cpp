#include "monitoring/deadline_fault_manager.h"

namespace automotive_scheduler {

DeadlineFaultManager::DeadlineFaultManager(Logger* logger)
    : logger_(logger), deadline_miss_count_(0) {}

void DeadlineFaultManager::CheckDeadlines(
    const std::vector<std::shared_ptr<TaskInstance>>& active_instances,
    int current_time_ms) {
  for (const auto& instance : active_instances) {
    const bool already_finished =
        instance->state() == TaskState::kCompleted ||
        instance->state() == TaskState::kDeadlineMissed;
    if (already_finished) {
      continue;
    }
    if (current_time_ms > instance->absolute_deadline_ms()) {
      instance->set_state(TaskState::kDeadlineMissed);
      ++deadline_miss_count_;
      if (logger_ != nullptr) {
        logger_->LogEvent(
            current_time_ms,
            "DEADLINE MISS: task=" + instance->task_id() +
                " instance=" + std::to_string(instance->instance_number()) +
                " deadline=" +
                std::to_string(instance->absolute_deadline_ms()));
      }
    }
  }
}

}  // namespace automotive_scheduler
