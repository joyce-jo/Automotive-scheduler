#include "monitoring/logger.h"

#include <ctime>
#include <iostream>

namespace automotive_scheduler {

namespace {

std::string CurrentWallClockTimestamp() {
  const std::time_t now = std::time(nullptr);
  char buffer[32];
  // Thread-safety is not a concern here: Logger is only ever driven by a
  // single simulation run on the main thread.
  std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S",
                std::localtime(&now));
  return std::string(buffer);
}

}  // namespace

Logger::Logger(std::string log_file_path)
    : log_file_path_(std::move(log_file_path)),
      // std::ios::app (not trunc): every run's log is appended to the
      // file rather than overwriting the previous run's history.
      log_stream_(log_file_path_, std::ios::out | std::ios::app) {
  if (!log_stream_.is_open()) {
    std::cerr << "Warning: unable to open log file '" << log_file_path_
              << "'. Log messages will not be persisted." << std::endl;
    return;
  }
  log_stream_ << "\n===== Simulation run started at "
              << CurrentWallClockTimestamp() << " =====" << std::endl;
}

Logger::~Logger() {
  if (log_stream_.is_open()) {
    log_stream_.close();
  }
}

void Logger::LogEvent(int simulated_time_ms, const std::string& message) {
  if (log_stream_.is_open()) {
    log_stream_ << "[t=" << simulated_time_ms << "ms] " << message
                << std::endl;
  }
}

}  // namespace automotive_scheduler
