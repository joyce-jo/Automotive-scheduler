#include "monitoring/logger.h"

#include <iostream>

namespace automotive_scheduler {

Logger::Logger(std::string log_file_path)
    : log_file_path_(std::move(log_file_path)),
      log_stream_(log_file_path_, std::ios::out | std::ios::trunc) {
  if (!log_stream_.is_open()) {
    std::cerr << "Warning: unable to open log file '" << log_file_path_
              << "'. Log messages will not be persisted." << std::endl;
  }
}

Logger::~Logger() {
  if (log_stream_.is_open()) {
    log_stream_.close();
  }
}

void Logger::LogEvent(int simulated_time_ms, const std::string& message) {
  if (log_stream_.is_open()) {
    log_stream_ << "[t=" << simulated_time_ms << "ms] " << message
                << std::endl;
  }
}

}  // namespace automotive_scheduler
