#include "monitoring/performance_monitor.h"

#include <ctime>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace automotive_scheduler {

PerformanceMonitor::PerformanceMonitor(int simulation_duration_ms,
                                        std::string report_output_path)
    : simulation_duration_ms_(simulation_duration_ms),
      report_output_path_(std::move(report_output_path)) {}

void PerformanceMonitor::RecordInstances(
    const std::vector<std::shared_ptr<TaskInstance>>& all_instances) {
  all_instances_ = all_instances;
}

std::string PerformanceMonitor::GenerateReport(
    const std::string& algorithm_name) {
  int completed_count = 0;
  int deadline_miss_count = 0;
  int total_waiting_time_ms = 0;
  int total_response_time_ms = 0;
  int total_preemptions = 0;
  int total_busy_time_ms = 0;
  int response_time_sample_count = 0;

  std::ostringstream report;
  report << "===== Performance Report (" << algorithm_name
         << ") =====" << std::endl;
  report << std::left << std::setw(10) << "Task" << std::setw(10)
         << "Instance" << std::setw(12) << "State" << std::setw(12)
         << "Waiting" << std::setw(12) << "Response" << std::setw(10)
         << "Preempts" << std::endl;

  for (const auto& instance : all_instances_) {
    total_preemptions += instance->preemption_count();
    total_waiting_time_ms += instance->waiting_time_ms();

    std::string state_label;
    int response_time_ms = -1;
    switch (instance->state()) {
      case TaskState::kCompleted:
        state_label = "Completed";
        ++completed_count;
        response_time_ms =
            instance->completion_time_ms() - instance->release_time_ms();
        total_response_time_ms += response_time_ms;
        total_busy_time_ms += response_time_ms - instance->waiting_time_ms();
        ++response_time_sample_count;
        break;
      case TaskState::kDeadlineMissed:
        state_label = "Missed";
        ++deadline_miss_count;
        break;
      default:
        state_label = "Incomplete";
        break;
    }

    report << std::left << std::setw(10) << instance->task_id()
           << std::setw(10) << instance->instance_number() << std::setw(12)
           << state_label << std::setw(12) << instance->waiting_time_ms()
           << std::setw(12) << response_time_ms << std::setw(10)
           << instance->preemption_count() << std::endl;
  }

  const double cpu_utilization_percent =
      simulation_duration_ms_ > 0
          ? (static_cast<double>(total_busy_time_ms) /
             simulation_duration_ms_) *
                100.0
          : 0.0;
  const double average_response_time_ms =
      response_time_sample_count > 0
          ? static_cast<double>(total_response_time_ms) /
                response_time_sample_count
          : 0.0;

  report << std::endl;
  report << "Completed Tasks       : " << completed_count << std::endl;
  report << "Deadline Misses       : " << deadline_miss_count << std::endl;
  report << "Total Waiting Time(ms): " << total_waiting_time_ms << std::endl;
  report << "Avg Response Time(ms) : " << std::fixed << std::setprecision(2)
         << average_response_time_ms << std::endl;
  report << "CPU Utilization (%)   : " << std::fixed << std::setprecision(2)
         << cpu_utilization_percent << std::endl;
  report << "Total Preemptions     : " << total_preemptions << std::endl;

  std::ofstream report_file(report_output_path_,
                             std::ios::out | std::ios::app);
  if (report_file.is_open()) {
    const std::time_t now = std::time(nullptr);
    char timestamp[32];
    std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S",
                  std::localtime(&now));
    report_file << "\n===== Report generated at " << timestamp
                << " =====\n";
    report_file << report.str();
  }

  return report.str();
}

}  // namespace automotive_scheduler
