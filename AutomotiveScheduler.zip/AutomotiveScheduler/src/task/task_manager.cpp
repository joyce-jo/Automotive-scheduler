#include "task/task_manager.h"

#include <algorithm>

namespace automotive_scheduler {

void TaskManager::AddTask(const Task& task) {
  tasks_.push_back(task);
  released_instance_counts_.push_back(0);
}

void TaskManager::DeriveRateMonotonicPriorities() {
  // Shorter period tasks receive a numerically higher priority value so
  // that "higher priority value" consistently means "more urgent" across
  // both Fixed Priority and RMS modes.
  std::vector<int> sorted_indices(tasks_.size());
  for (std::size_t i = 0; i < tasks_.size(); ++i) {
    sorted_indices[i] = static_cast<int>(i);
  }
  std::sort(sorted_indices.begin(), sorted_indices.end(),
            [this](int lhs, int rhs) {
              return tasks_[lhs].period_ms() < tasks_[rhs].period_ms();
            });

  const int task_count = static_cast<int>(sorted_indices.size());
  for (int rank = 0; rank < task_count; ++rank) {
    const int task_index = sorted_indices[rank];
    // The shortest-period task gets the highest priority value.
    const int priority_value = task_count - rank;
    tasks_[task_index].set_effective_priority(priority_value);
  }
}

std::vector<std::shared_ptr<TaskInstance>> TaskManager::ReleaseDueInstances(
    int current_time_ms) {
  std::vector<std::shared_ptr<TaskInstance>> released;
  for (std::size_t i = 0; i < tasks_.size(); ++i) {
    const Task& task = tasks_[i];
    if (task.period_ms() <= 0) {
      continue;
    }
    if (current_time_ms % task.period_ms() == 0) {
      const int instance_number = released_instance_counts_[i];
      const int absolute_deadline_ms = current_time_ms + task.deadline_ms();
      auto instance = std::make_shared<TaskInstance>(
          task.task_id(), instance_number, current_time_ms,
          task.execution_time_ms(), absolute_deadline_ms,
          task.effective_priority());
      instance->set_state(TaskState::kReady);
      released.push_back(instance);
      ++released_instance_counts_[i];
    }
  }
  return released;
}

}  // namespace automotive_scheduler
