#include "task/task_instance.h"

namespace automotive_scheduler {

TaskInstance::TaskInstance(std::string task_id, int instance_number,
                            int release_time_ms, int execution_time_ms,
                            int absolute_deadline_ms, int priority)
    : task_id_(std::move(task_id)),
      instance_number_(instance_number),
      release_time_ms_(release_time_ms),
      execution_time_ms_(execution_time_ms),
      absolute_deadline_ms_(absolute_deadline_ms),
      priority_(priority),
      remaining_execution_time_ms_(execution_time_ms),
      state_(TaskState::kCreated),
      completion_time_ms_(-1),
      first_run_time_ms_(-1),
      preemption_count_(0),
      waiting_time_ms_(0) {}

void TaskInstance::ConsumeExecutionTime(int elapsed_ms) {
  remaining_execution_time_ms_ -= elapsed_ms;
  if (remaining_execution_time_ms_ < 0) {
    remaining_execution_time_ms_ = 0;
  }
}

void TaskInstance::RecordFirstRun(int time_ms) {
  if (first_run_time_ms_ < 0) {
    first_run_time_ms_ = time_ms;
  }
}

}  // namespace automotive_scheduler
