#include "task/task.h"

namespace automotive_scheduler {

Task::Task(std::string task_id, int period_ms, int execution_time_ms,
           int deadline_ms, int configured_priority, std::string task_name,
           TaskType task_type)
    : task_id_(std::move(task_id)),
      task_name_(std::move(task_name)),
      task_type_(task_type),
      period_ms_(period_ms),
      execution_time_ms_(execution_time_ms),
      deadline_ms_(deadline_ms),
      configured_priority_(configured_priority),
      effective_priority_(configured_priority) {}

}  // namespace automotive_scheduler
