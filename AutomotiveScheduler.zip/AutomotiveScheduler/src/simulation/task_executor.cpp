#include "simulation/task_executor.h"

namespace automotive_scheduler {

TaskExecutor::TaskExecutor(Logger* logger) : logger_(logger) {}

void TaskExecutor::Execute(const std::shared_ptr<TaskInstance>& instance,
                            int elapsed_ms, int current_time_ms) {
  if (!instance->has_started_running()) {
    instance->RecordFirstRun(current_time_ms - elapsed_ms);
  }
  instance->set_state(TaskState::kRunning);
  instance->ConsumeExecutionTime(elapsed_ms);

  if (instance->remaining_execution_time_ms() == 0) {
    instance->set_state(TaskState::kCompleted);
    instance->set_completion_time_ms(current_time_ms);
    if (logger_ != nullptr) {
      logger_->LogEvent(current_time_ms,
                         "COMPLETED: task=" + instance->task_id() +
                             " instance=" +
                             std::to_string(instance->instance_number()));
    }
  }
}

}  // namespace automotive_scheduler
