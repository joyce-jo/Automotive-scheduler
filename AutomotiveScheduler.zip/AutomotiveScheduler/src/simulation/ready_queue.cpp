#include "simulation/ready_queue.h"

#include <algorithm>

namespace automotive_scheduler {

void ReadyQueue::Insert(const std::shared_ptr<TaskInstance>& instance) {
  instances_.push_back(instance);
}

void ReadyQueue::RemoveFinishedInstances() {
  instances_.erase(
      std::remove_if(instances_.begin(), instances_.end(),
                      [](const std::shared_ptr<TaskInstance>& instance) {
                        return instance->state() == TaskState::kCompleted ||
                               instance->state() ==
                                   TaskState::kDeadlineMissed;
                      }),
      instances_.end());
}

}  // namespace automotive_scheduler
