#include "scheduler/real_time_scheduler.h"

namespace automotive_scheduler {

RealTimeScheduler::RealTimeScheduler(
    std::unique_ptr<SchedulingAlgorithm> algorithm, Logger* logger)
    : algorithm_(std::move(algorithm)),
      logger_(logger),
      currently_running_(nullptr),
      algorithm_name_(algorithm_->algorithm_name()) {}

std::shared_ptr<TaskInstance> RealTimeScheduler::MakeSchedulingDecision(
    const ReadyQueue& ready_queue, int current_time_ms) {
  const std::shared_ptr<TaskInstance> selected =
      algorithm_->SelectNextInstance(ready_queue.instances());

  const bool previous_still_active =
      currently_running_ != nullptr &&
      currently_running_->state() != TaskState::kCompleted &&
      currently_running_->state() != TaskState::kDeadlineMissed;

  if (previous_still_active && selected != currently_running_) {
    currently_running_->IncrementPreemptionCount();
    currently_running_->set_state(TaskState::kReady);
    if (logger_ != nullptr) {
      logger_->LogEvent(
          current_time_ms,
          "PREEMPTED: task=" + currently_running_->task_id() +
              " instance=" +
              std::to_string(currently_running_->instance_number()) +
              " by task=" +
              (selected != nullptr ? selected->task_id() : "none"));
    }
  }

  currently_running_ = selected;
  return selected;
}

}  // namespace automotive_scheduler
