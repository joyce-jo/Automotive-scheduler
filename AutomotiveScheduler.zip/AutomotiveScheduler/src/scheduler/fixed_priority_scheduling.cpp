#include "scheduler/fixed_priority_scheduling.h"

namespace automotive_scheduler {

std::shared_ptr<TaskInstance> FixedPriorityScheduling::SelectNextInstance(
    const std::vector<std::shared_ptr<TaskInstance>>& candidates) const {
  std::shared_ptr<TaskInstance> selected = nullptr;
  for (const auto& candidate : candidates) {
    const bool is_terminal =
        candidate->state() == TaskState::kCompleted ||
        candidate->state() == TaskState::kDeadlineMissed;
    if (is_terminal) {
      continue;
    }
    if (selected == nullptr || candidate->priority() > selected->priority() ||
        (candidate->priority() == selected->priority() &&
         candidate->release_time_ms() < selected->release_time_ms())) {
      selected = candidate;
    }
  }
  return selected;
}

}  // namespace automotive_scheduler
