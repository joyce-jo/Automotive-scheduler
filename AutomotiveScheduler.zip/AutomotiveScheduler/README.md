# Priority-Based Real-Time Scheduler Simulator for Automotive Systems

A C++17 simulator that models how an automotive Electronic Control Unit
(ECU) schedules safety-critical, periodic tasks (crash detection, brake
control, dashboard updates, etc.) under two real-time scheduling
policies, per Requirement Specification v2.0:

- **Fixed Priority Scheduling** — tasks run in user-configured priority order.
- **Rate Monotonic Scheduling (RMS)** — priority is derived automatically
  from period (shorter period = higher priority).

Both policies are preemptive and driven by a Virtual Clock that always
starts at 0 ms.

## Design principles followed

- **No hardcoded values.** Every simulation and task parameter
  (duration, time step, algorithm choice, task periods/execution
  times/deadlines/priorities, log and report paths) is read at runtime
  from the files in `config/`. Nothing simulation-specific is compiled
  into the source.
- **Google C++ Style Guide.** `.clang-format` is set to
  `BasedOnStyle: Google`. Naming follows the guide: `PascalCase` for
  classes/functions, `snake_case_` for member variables, `kPascalCase`
  for enumerators, header guards named
  `AUTOMOTIVE_SCHEDULER_<PATH>_<FILE>_H_`, one class per header/source
  pair, `#include` ordering (related header first, then C++ standard
  library, then project headers).
- **Object-oriented / SOLID.** Each requirement-spec component (Task
  Manager, Configuration Manager, Real-Time Scheduler, Virtual Clock,
  Ready Queue, Task Executor, Deadline & Fault Manager, Logger,
  Performance Monitor, Main Controller) is its own class with a single
  responsibility. `SchedulingAlgorithm` is an abstract strategy interface
  implemented polymorphically by `FixedPriorityScheduling` and
  `RateMonotonicScheduling`, so the scheduler's control-loop logic never
  changes when the policy changes (see Section 9 of the spec).

## Directory structure

```
AutomotiveScheduler/
├── include/            # Public headers, mirrors src/
│   ├── task/            Task, TaskInstance, TaskManager
│   ├── configuration/    ConfigurationManager, SimulationConfig
│   ├── scheduler/        SchedulingAlgorithm strategy + RealTimeScheduler
│   ├── simulation/       VirtualClock, ReadyQueue, TaskExecutor
│   ├── monitoring/       Logger, DeadlineFaultManager, PerformanceMonitor
│   └── controller/       MainController
├── src/                 Matching .cpp implementations
├── tests/                Lightweight assert-based unit tests, one per module folder
├── config/               Runtime configuration files (edit these, not the code)
├── logs/                 Generated scheduling event log (git-ignorable output)
├── reports/              Generated performance report (git-ignorable output)
├── main.cpp
├── CMakeLists.txt
├── .clang-format
└── README.md
```

## Building

Requires a C++17 compiler. Two options:

### CMake (preferred)

```bash
mkdir build && cd build
cmake ..
cmake --build .
ctest              # runs all unit tests
./automotive_scheduler
```

### Direct g++ (no CMake required)

```bash
g++ -std=c++17 -Wall -Wextra -Iinclude \
    src/task/*.cpp src/configuration/*.cpp src/scheduler/*.cpp \
    src/simulation/*.cpp src/monitoring/*.cpp src/controller/*.cpp \
    main.cpp -o automotive_scheduler
./automotive_scheduler
```

By default the program reads `config/simulation_config.txt` and
`config/tasks_config.txt`. You may point it at any other pair of files:

```bash
./automotive_scheduler path/to/simulation_config.txt path/to/tasks_config.txt
```

## Configuration format

`config/simulation_config.txt` (key=value):

```
simulation_duration_ms=50
time_step_ms=1
scheduling_algorithm=RATE_MONOTONIC   # or FIXED_PRIORITY
log_output_path=logs/simulation_log.txt
report_output_path=reports/performance_report.txt
```

`config/tasks_config.txt` (CSV, one row per task template):

```
task_id,period_ms,execution_time_ms,deadline_ms,fixed_priority
T1,5,1,5,3
T2,10,2,10,2
T3,20,5,20,1
```

`fixed_priority` is only used when `scheduling_algorithm=FIXED_PRIORITY`.
Under `RATE_MONOTONIC`, `TaskManager::DeriveRateMonotonicPriorities()`
overwrites it with a priority derived from `period_ms`.

`ConfigurationManager` validates the loaded configuration (FR-03) before
the simulation starts and rejects it (with a clear message, no crash) if,
for example, a task's execution time exceeds its deadline, a required
field is missing, or a file cannot be opened.

## Simulation flow (maps to Section 6 of the spec)

1. Load and validate configuration.
2. Reset the Virtual Clock to 0 ms; if RMS is selected, derive priorities.
3. Release the initial (t = 0 ms) task instances into the Ready Queue.
4. Loop while `current_time_ms < simulation_duration_ms`:
   a. Advance the Virtual Clock by `time_step_ms`.
   b. Release any task instances due at the new time.
   c. `RealTimeScheduler` selects the highest-priority ready instance;
      if this differs from the previously running instance, that
      instance is preempted (its preemption count is incremented and
      the event is logged).
   d. Every other ready instance accrues waiting time for this tick.
   e. `TaskExecutor` advances the selected instance's execution and
      marks it Completed if it finishes.
   f. `DeadlineFaultManager` checks every active instance against its
      absolute deadline and marks any violation as Deadline Missed.
5. `PerformanceMonitor` aggregates completed tasks, deadline misses,
   waiting time, response time, CPU utilization, and preemptions, and
   writes the report to `report_output_path` (also printed to stdout).

## Tests

`tests/` contains one assert-based test file per module folder
(`task`, `configuration`, `scheduler`, `simulation`, `monitoring`),
covering: task release timing, RMS priority derivation, configuration
validation (accept/reject), priority selection and tie-breaking,
preemption exclusion of terminal instances, virtual clock behavior,
ready queue cleanup, task execution/completion, deadline-miss
detection, and report content. Run them individually with g++ or all
together via `ctest` after a CMake build.

## Extending

To add a new scheduling policy: implement `SchedulingAlgorithm`
(`include/scheduler/scheduling_algorithm.h`), add the new source file
under `src/scheduler/`, and register it in
`MainController::CreateAlgorithm`. No other file needs to change,
per NFR-02 (Modularity) and NFR-03 (Maintainability).
