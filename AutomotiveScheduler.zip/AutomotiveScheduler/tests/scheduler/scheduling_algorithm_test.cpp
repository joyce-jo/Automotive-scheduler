// Unit tests for FixedPriorityScheduling and RateMonotonicScheduling.
#include <cassert>
#include <iostream>
#include <memory>
#include <vector>

#include "scheduler/fixed_priority_scheduling.h"
#include "scheduler/rate_monotonic_scheduling.h"
#include "task/task_instance.h"

namespace {

using automotive_scheduler::FixedPriorityScheduling;
using automotive_scheduler::RateMonotonicScheduling;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskState;

void TestHighestPriorityIsSelected() {
  auto low = std::make_shared<TaskInstance>("T_LOW", 0, 0, 5, 20, 1);
  auto high = std::make_shared<TaskInstance>("T_HIGH", 0, 0, 5, 5, 3);
  low->set_state(TaskState::kReady);
  high->set_state(TaskState::kReady);

  FixedPriorityScheduling algorithm;
  const auto selected = algorithm.SelectNextInstance({low, high});
  assert(selected == high);
}

void TestTieBrokenByEarliestReleaseTime() {
  auto later = std::make_shared<TaskInstance>("T_A", 0, 5, 5, 20, 2);
  auto earlier = std::make_shared<TaskInstance>("T_B", 0, 2, 5, 20, 2);
  later->set_state(TaskState::kReady);
  earlier->set_state(TaskState::kReady);

  RateMonotonicScheduling algorithm;
  const auto selected = algorithm.SelectNextInstance({later, earlier});
  assert(selected == earlier);
}

void TestTerminalInstancesAreExcluded() {
  auto completed = std::make_shared<TaskInstance>("T_DONE", 0, 0, 5, 5, 5);
  completed->set_state(TaskState::kCompleted);
  auto ready = std::make_shared<TaskInstance>("T_READY", 0, 0, 5, 20, 1);
  ready->set_state(TaskState::kReady);

  FixedPriorityScheduling algorithm;
  const auto selected = algorithm.SelectNextInstance({completed, ready});
  assert(selected == ready);
}

}  // namespace

int main() {
  TestHighestPriorityIsSelected();
  TestTieBrokenByEarliestReleaseTime();
  TestTerminalInstancesAreExcluded();
  std::cout << "scheduling_algorithm_test: all tests passed." << std::endl;
  return 0;
}
