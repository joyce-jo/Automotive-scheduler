// GoogleTest suite for FixedPriorityScheduling and RateMonotonicScheduling.
#include <gtest/gtest.h>

#include <memory>
#include <vector>

#include "scheduler/fixed_priority_scheduling.h"
#include "scheduler/rate_monotonic_scheduling.h"
#include "task/task_instance.h"

namespace {

using automotive_scheduler::FixedPriorityScheduling;
using automotive_scheduler::RateMonotonicScheduling;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskState;

TEST(FixedPriorityTest, SelectsHighestPriorityInstance) {
  auto low = std::make_shared<TaskInstance>("T_LOW", 0, 0, 5, 20, 1);
  auto high = std::make_shared<TaskInstance>("T_HIGH", 0, 0, 5, 5, 3);
  low->set_state(TaskState::kReady);
  high->set_state(TaskState::kReady);

  FixedPriorityScheduling algorithm;
  EXPECT_EQ(algorithm.SelectNextInstance({low, high}), high);
}

TEST(FixedPriorityTest, ExcludesTerminalInstances) {
  auto completed = std::make_shared<TaskInstance>("T_DONE", 0, 0, 5, 5, 5);
  completed->set_state(TaskState::kCompleted);
  auto ready = std::make_shared<TaskInstance>("T_READY", 0, 0, 5, 20, 1);
  ready->set_state(TaskState::kReady);

  FixedPriorityScheduling algorithm;
  EXPECT_EQ(algorithm.SelectNextInstance({completed, ready}), ready);
}

TEST(RateMonotonicTest, TiesAreBrokenByEarliestReleaseTime) {
  auto later = std::make_shared<TaskInstance>("T_A", 0, /*release_time_ms=*/5,
                                               5, 20, 2);
  auto earlier = std::make_shared<TaskInstance>(
      "T_B", 0, /*release_time_ms=*/2, 5, 20, 2);
  later->set_state(TaskState::kReady);
  earlier->set_state(TaskState::kReady);

  RateMonotonicScheduling algorithm;
  EXPECT_EQ(algorithm.SelectNextInstance({later, earlier}), earlier);
}

TEST(RateMonotonicTest, ReturnsNullptrWhenNoCandidatesAreEligible) {
  auto missed = std::make_shared<TaskInstance>("T_MISSED", 0, 0, 5, 5, 3);
  missed->set_state(TaskState::kDeadlineMissed);

  RateMonotonicScheduling algorithm;
  EXPECT_EQ(algorithm.SelectNextInstance({missed}), nullptr);
}

}  // namespace
