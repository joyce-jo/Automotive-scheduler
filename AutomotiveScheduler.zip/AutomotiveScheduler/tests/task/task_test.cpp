// Unit tests for Task, TaskInstance, and TaskManager.
#include <cassert>
#include <iostream>

#include "task/task.h"
#include "task/task_instance.h"
#include "task/task_manager.h"

namespace {

using automotive_scheduler::Task;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskManager;
using automotive_scheduler::TaskState;
using automotive_scheduler::TaskType;

void TestTaskDefaultsToEmptyNameAndControlType() {
  // Existing call sites (file-based configuration) omit name/type; they
  // must still compile and default sensibly.
  Task task("T1", 5, 1, 5, 3);
  assert(task.task_name().empty());
  assert(task.task_type() == TaskType::kControl);
}

void TestTaskAcceptsOptionalNameAndType() {
  Task task("T1", 5, 1, 5, 3, "Engine Sensor", TaskType::kSensor);
  assert(task.task_name() == "Engine Sensor");
  assert(task.task_type() == TaskType::kSensor);
  assert(automotive_scheduler::ToString(task.task_type()) == "Sensor");
}

void TestTaskInstanceLifecycle() {
  TaskInstance instance("T1", 0, /*release_time_ms=*/0,
                         /*execution_time_ms=*/5, /*absolute_deadline_ms=*/5,
                         /*priority=*/3);
  assert(instance.state() == TaskState::kCreated);
  assert(instance.remaining_execution_time_ms() == 5);

  instance.set_state(TaskState::kReady);
  instance.ConsumeExecutionTime(2);
  assert(instance.remaining_execution_time_ms() == 3);

  instance.ConsumeExecutionTime(10);
  assert(instance.remaining_execution_time_ms() == 0);
}

void TestRateMonotonicPriorityDerivation() {
  TaskManager manager;
  manager.AddTask(Task("T1", /*period_ms=*/5, 1, 5, 3));
  manager.AddTask(Task("T2", /*period_ms=*/10, 2, 10, 2));
  manager.AddTask(Task("T3", /*period_ms=*/20, 5, 20, 1));

  manager.DeriveRateMonotonicPriorities();

  const auto& tasks = manager.tasks();
  assert(tasks[0].effective_priority() > tasks[1].effective_priority());
  assert(tasks[1].effective_priority() > tasks[2].effective_priority());
}

void TestTaskReleaseAtPeriodBoundaries() {
  TaskManager manager;
  manager.AddTask(Task("T1", /*period_ms=*/5, 1, 5, 3));

  const auto released_at_zero = manager.ReleaseDueInstances(0);
  assert(released_at_zero.size() == 1);

  const auto released_at_three = manager.ReleaseDueInstances(3);
  assert(released_at_three.empty());

  const auto released_at_five = manager.ReleaseDueInstances(5);
  assert(released_at_five.size() == 1);
  assert(released_at_five[0]->instance_number() == 1);
}

}  // namespace

int main() {
  TestTaskDefaultsToEmptyNameAndControlType();
  TestTaskAcceptsOptionalNameAndType();
  TestTaskInstanceLifecycle();
  TestRateMonotonicPriorityDerivation();
  TestTaskReleaseAtPeriodBoundaries();
  std::cout << "task_test: all tests passed." << std::endl;
  return 0;
}
