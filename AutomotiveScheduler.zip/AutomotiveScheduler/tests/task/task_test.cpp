// GoogleTest suite for Task, TaskInstance, and TaskManager.
#include <gtest/gtest.h>

#include "task/task.h"
#include "task/task_instance.h"
#include "task/task_manager.h"

namespace {

using automotive_scheduler::Task;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskManager;
using automotive_scheduler::TaskState;
using automotive_scheduler::TaskType;

TEST(TaskTest, DefaultsToEmptyNameAndControlType) {
  // Existing call sites (file-based configuration) omit name/type; they
  // must still compile and default sensibly.
  const Task task("T1", 5, 1, 5, 3);
  EXPECT_TRUE(task.task_name().empty());
  EXPECT_EQ(task.task_type(), TaskType::kControl);
}

TEST(TaskTest, AcceptsOptionalNameAndType) {
  const Task task("T1", 5, 1, 5, 3, "Engine Sensor", TaskType::kSensor);
  EXPECT_EQ(task.task_name(), "Engine Sensor");
  EXPECT_EQ(task.task_type(), TaskType::kSensor);
  EXPECT_EQ(automotive_scheduler::ToString(task.task_type()), "Sensor");
}

TEST(TaskInstanceTest, TracksExecutionProgress) {
  TaskInstance instance("T1", 0, /*release_time_ms=*/0,
                         /*execution_time_ms=*/5, /*absolute_deadline_ms=*/5,
                         /*priority=*/3);
  EXPECT_EQ(instance.state(), TaskState::kCreated);
  EXPECT_EQ(instance.remaining_execution_time_ms(), 5);

  instance.set_state(TaskState::kReady);
  instance.ConsumeExecutionTime(2);
  EXPECT_EQ(instance.remaining_execution_time_ms(), 3);

  instance.ConsumeExecutionTime(10);
  EXPECT_EQ(instance.remaining_execution_time_ms(), 0);
}

TEST(TaskManagerTest, DerivesRateMonotonicPrioritiesFromPeriod) {
  TaskManager manager;
  manager.AddTask(Task("T1", /*period_ms=*/5, 1, 5, 3));
  manager.AddTask(Task("T2", /*period_ms=*/10, 2, 10, 2));
  manager.AddTask(Task("T3", /*period_ms=*/20, 5, 20, 1));

  manager.DeriveRateMonotonicPriorities();

  const auto& tasks = manager.tasks();
  EXPECT_GT(tasks[0].effective_priority(), tasks[1].effective_priority());
  EXPECT_GT(tasks[1].effective_priority(), tasks[2].effective_priority());
}

TEST(TaskManagerTest, ReleasesInstancesAtPeriodBoundaries) {
  TaskManager manager;
  manager.AddTask(Task("T1", /*period_ms=*/5, 1, 5, 3));

  const auto released_at_zero = manager.ReleaseDueInstances(0);
  EXPECT_EQ(released_at_zero.size(), 1u);

  const auto released_at_three = manager.ReleaseDueInstances(3);
  EXPECT_TRUE(released_at_three.empty());

  const auto released_at_five = manager.ReleaseDueInstances(5);
  ASSERT_EQ(released_at_five.size(), 1u);
  EXPECT_EQ(released_at_five[0]->instance_number(), 1);
}

}  // namespace
