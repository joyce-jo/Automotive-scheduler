// Unit tests for VirtualClock, ReadyQueue, and TaskExecutor.
#include <cassert>
#include <iostream>
#include <memory>

#include "simulation/ready_queue.h"
#include "simulation/task_executor.h"
#include "simulation/virtual_clock.h"
#include "task/task_instance.h"

namespace {

using automotive_scheduler::ReadyQueue;
using automotive_scheduler::TaskExecutor;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskState;
using automotive_scheduler::VirtualClock;

void TestVirtualClockStartsAtZeroAndAdvances() {
  VirtualClock clock;
  assert(clock.current_time_ms() == 0);
  clock.Advance(3);
  assert(clock.current_time_ms() == 3);
  clock.Reset();
  assert(clock.current_time_ms() == 0);
}

void TestReadyQueueRemovesFinishedInstances() {
  ReadyQueue queue;
  auto completed = std::make_shared<TaskInstance>("T1", 0, 0, 5, 5, 3);
  completed->set_state(TaskState::kCompleted);
  auto active = std::make_shared<TaskInstance>("T2", 0, 0, 5, 20, 1);
  active->set_state(TaskState::kReady);

  queue.Insert(completed);
  queue.Insert(active);
  assert(queue.instances().size() == 2);

  queue.RemoveFinishedInstances();
  assert(queue.instances().size() == 1);
  assert(queue.instances()[0] == active);
}

void TestTaskExecutorCompletesInstance() {
  TaskExecutor executor(/*logger=*/nullptr);
  auto instance = std::make_shared<TaskInstance>("T1", 0, 0, 2, 5, 3);

  executor.Execute(instance, /*elapsed_ms=*/1, /*current_time_ms=*/1);
  assert(instance->state() == TaskState::kRunning);
  assert(instance->remaining_execution_time_ms() == 1);

  executor.Execute(instance, /*elapsed_ms=*/1, /*current_time_ms=*/2);
  assert(instance->state() == TaskState::kCompleted);
  assert(instance->completion_time_ms() == 2);
}

}  // namespace

int main() {
  TestVirtualClockStartsAtZeroAndAdvances();
  TestReadyQueueRemovesFinishedInstances();
  TestTaskExecutorCompletesInstance();
  std::cout << "virtual_clock_test: all tests passed." << std::endl;
  return 0;
}
