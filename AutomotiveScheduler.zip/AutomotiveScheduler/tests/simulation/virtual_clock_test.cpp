// GoogleTest suite for VirtualClock, ReadyQueue, and TaskExecutor.
#include <gtest/gtest.h>

#include <memory>

#include "simulation/ready_queue.h"
#include "simulation/task_executor.h"
#include "simulation/virtual_clock.h"
#include "task/task_instance.h"

namespace {

using automotive_scheduler::ReadyQueue;
using automotive_scheduler::TaskExecutor;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskState;
using automotive_scheduler::VirtualClock;

TEST(VirtualClockTest, StartsAtZeroAndAdvances) {
  VirtualClock clock;
  EXPECT_EQ(clock.current_time_ms(), 0);
  clock.Advance(3);
  EXPECT_EQ(clock.current_time_ms(), 3);
  clock.Reset();
  EXPECT_EQ(clock.current_time_ms(), 0);
}

TEST(ReadyQueueTest, RemovesFinishedInstancesOnly) {
  ReadyQueue queue;
  auto completed = std::make_shared<TaskInstance>("T1", 0, 0, 5, 5, 3);
  completed->set_state(TaskState::kCompleted);
  auto active = std::make_shared<TaskInstance>("T2", 0, 0, 5, 20, 1);
  active->set_state(TaskState::kReady);

  queue.Insert(completed);
  queue.Insert(active);
  EXPECT_EQ(queue.instances().size(), 2u);

  queue.RemoveFinishedInstances();
  ASSERT_EQ(queue.instances().size(), 1u);
  EXPECT_EQ(queue.instances()[0], active);
}

TEST(TaskExecutorTest, CompletesInstanceWhenExecutionTimeIsConsumed) {
  TaskExecutor executor(/*logger=*/nullptr);
  auto instance = std::make_shared<TaskInstance>("T1", 0, 0, 2, 5, 3);

  executor.Execute(instance, /*elapsed_ms=*/1, /*current_time_ms=*/1);
  EXPECT_EQ(instance->state(), TaskState::kRunning);
  EXPECT_EQ(instance->remaining_execution_time_ms(), 1);

  executor.Execute(instance, /*elapsed_ms=*/1, /*current_time_ms=*/2);
  EXPECT_EQ(instance->state(), TaskState::kCompleted);
  EXPECT_EQ(instance->completion_time_ms(), 2);
}

}  // namespace
