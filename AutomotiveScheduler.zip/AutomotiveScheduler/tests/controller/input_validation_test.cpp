// GoogleTest suite for the pure (I/O-free) console input validation
// helpers.
#include <gtest/gtest.h>

#include "controller/input_validation.h"

namespace {

using automotive_scheduler::IsExecutionTimeWithinDeadline;
using automotive_scheduler::IsNonEmptyAfterTrim;
using automotive_scheduler::TryParsePositiveInt;

TEST(InputValidationTest, TryParsePositiveIntAcceptsValidInput) {
  int value = 0;
  EXPECT_TRUE(TryParsePositiveInt("5", &value));
  EXPECT_EQ(value, 5);

  EXPECT_TRUE(TryParsePositiveInt("  42  ", &value));
  EXPECT_EQ(value, 42);
}

TEST(InputValidationTest, TryParsePositiveIntRejectsInvalidInput) {
  int value = 0;
  EXPECT_FALSE(TryParsePositiveInt("-5", &value));
  EXPECT_FALSE(TryParsePositiveInt("0", &value));
  EXPECT_FALSE(TryParsePositiveInt("abc", &value));
  EXPECT_FALSE(TryParsePositiveInt("12abc", &value));
  EXPECT_FALSE(TryParsePositiveInt("", &value));
  EXPECT_FALSE(TryParsePositiveInt("   ", &value));
}

TEST(InputValidationTest, IsNonEmptyAfterTrimDetectsBlankText) {
  EXPECT_TRUE(IsNonEmptyAfterTrim("Engine Sensor"));
  EXPECT_FALSE(IsNonEmptyAfterTrim(""));
  EXPECT_FALSE(IsNonEmptyAfterTrim("   "));
}

TEST(InputValidationTest, IsExecutionTimeWithinDeadlineEnforcesRule) {
  EXPECT_TRUE(IsExecutionTimeWithinDeadline(2, 10));
  EXPECT_TRUE(IsExecutionTimeWithinDeadline(10, 10));
  EXPECT_FALSE(IsExecutionTimeWithinDeadline(15, 10));
}

}  // namespace
