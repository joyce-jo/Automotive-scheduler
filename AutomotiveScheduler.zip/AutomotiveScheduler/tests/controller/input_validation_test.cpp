// Unit tests for the pure (I/O-free) console input validation helpers.
#include <cassert>
#include <iostream>

#include "controller/input_validation.h"

namespace {

using automotive_scheduler::IsExecutionTimeWithinDeadline;
using automotive_scheduler::IsNonEmptyAfterTrim;
using automotive_scheduler::TryParsePositiveInt;

void TestTryParsePositiveIntAcceptsValidInput() {
  int value = 0;
  assert(TryParsePositiveInt("5", &value));
  assert(value == 5);

  assert(TryParsePositiveInt("  42  ", &value));
  assert(value == 42);
}

void TestTryParsePositiveIntRejectsInvalidInput() {
  int value = 0;
  assert(!TryParsePositiveInt("-5", &value));
  assert(!TryParsePositiveInt("0", &value));
  assert(!TryParsePositiveInt("abc", &value));
  assert(!TryParsePositiveInt("12abc", &value));
  assert(!TryParsePositiveInt("", &value));
  assert(!TryParsePositiveInt("   ", &value));
}

void TestIsNonEmptyAfterTrim() {
  assert(IsNonEmptyAfterTrim("Engine Sensor"));
  assert(!IsNonEmptyAfterTrim(""));
  assert(!IsNonEmptyAfterTrim("   "));
}

void TestIsExecutionTimeWithinDeadline() {
  assert(IsExecutionTimeWithinDeadline(2, 10));
  assert(IsExecutionTimeWithinDeadline(10, 10));
  assert(!IsExecutionTimeWithinDeadline(15, 10));
}

}  // namespace

int main() {
  TestTryParsePositiveIntAcceptsValidInput();
  TestTryParsePositiveIntRejectsInvalidInput();
  TestIsNonEmptyAfterTrim();
  TestIsExecutionTimeWithinDeadline();
  std::cout << "input_validation_test: all tests passed." << std::endl;
  return 0;
}
