// GoogleTest suite for ConfigurationManager.
#include <gtest/gtest.h>

#include <fstream>
#include <string>

#include "configuration/configuration_manager.h"

namespace {

using automotive_scheduler::ConfigurationManager;
using automotive_scheduler::SchedulingAlgorithmType;
using automotive_scheduler::SimulationConfig;

void WriteFile(const std::string& path, const std::string& content) {
  std::ofstream out(path, std::ios::out | std::ios::trunc);
  out << content;
}

TEST(ConfigurationManagerTest, LoadsAndValidatesWellFormedConfiguration) {
  const std::string sim_path = "test_sim_config_valid.txt";
  const std::string tasks_path = "test_tasks_config_valid.txt";

  WriteFile(sim_path,
            "simulation_duration_ms=50\n"
            "time_step_ms=1\n"
            "scheduling_algorithm=RATE_MONOTONIC\n"
            "log_output_path=logs/test_log.txt\n"
            "report_output_path=reports/test_report.txt\n");
  WriteFile(tasks_path,
            "task_id,period_ms,execution_time_ms,deadline_ms,fixed_priority\n"
            "T1,5,1,5,3\n"
            "T2,10,2,10,2\n");

  ConfigurationManager manager(sim_path, tasks_path);
  SimulationConfig config;
  std::string error_message;
  const bool loaded = manager.LoadAndValidate(&config, &error_message);

  EXPECT_TRUE(loaded);
  EXPECT_EQ(config.simulation_duration_ms, 50);
  EXPECT_EQ(config.scheduling_algorithm,
            SchedulingAlgorithmType::kRateMonotonic);
  ASSERT_EQ(config.tasks.size(), 2u);
}

TEST(ConfigurationManagerTest, RejectsExecutionTimeGreaterThanDeadline) {
  const std::string sim_path = "test_sim_config_invalid.txt";
  const std::string tasks_path = "test_tasks_config_invalid.txt";

  WriteFile(sim_path,
            "simulation_duration_ms=50\n"
            "time_step_ms=1\n"
            "scheduling_algorithm=FIXED_PRIORITY\n"
            "log_output_path=logs/test_log.txt\n"
            "report_output_path=reports/test_report.txt\n");
  // Execution time (100) exceeds deadline (5) -> invalid.
  WriteFile(tasks_path,
            "task_id,period_ms,execution_time_ms,deadline_ms,fixed_priority\n"
            "T1,5,100,5,3\n");

  ConfigurationManager manager(sim_path, tasks_path);
  SimulationConfig config;
  std::string error_message;
  const bool loaded = manager.LoadAndValidate(&config, &error_message);

  EXPECT_FALSE(loaded);
  EXPECT_FALSE(error_message.empty());
}

TEST(ConfigurationManagerTest, RejectsMissingSimulationFile) {
  ConfigurationManager manager("does_not_exist_sim.txt",
                                "does_not_exist_tasks.txt");
  SimulationConfig config;
  std::string error_message;

  EXPECT_FALSE(manager.LoadAndValidate(&config, &error_message));
  EXPECT_FALSE(error_message.empty());
}

}  // namespace
