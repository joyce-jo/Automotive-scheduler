// Unit tests for ConfigurationManager.
#include <cassert>
#include <fstream>
#include <iostream>
#include <string>

#include "configuration/configuration_manager.h"

namespace {

using automotive_scheduler::ConfigurationManager;
using automotive_scheduler::SchedulingAlgorithmType;
using automotive_scheduler::SimulationConfig;

void WriteFile(const std::string& path, const std::string& content) {
  std::ofstream out(path, std::ios::out | std::ios::trunc);
  out << content;
}

void TestValidConfigurationLoads() {
  const std::string sim_path = "test_sim_config_valid.txt";
  const std::string tasks_path = "test_tasks_config_valid.txt";

  WriteFile(sim_path,
            "simulation_duration_ms=50\n"
            "time_step_ms=1\n"
            "scheduling_algorithm=RATE_MONOTONIC\n"
            "log_output_path=logs/test_log.txt\n"
            "report_output_path=reports/test_report.txt\n");
  WriteFile(tasks_path,
            "task_id,period_ms,execution_time_ms,deadline_ms,fixed_priority\n"
            "T1,5,1,5,3\n"
            "T2,10,2,10,2\n");

  ConfigurationManager manager(sim_path, tasks_path);
  SimulationConfig config;
  std::string error_message;
  const bool loaded = manager.LoadAndValidate(&config, &error_message);

  assert(loaded);
  assert(config.simulation_duration_ms == 50);
  assert(config.scheduling_algorithm ==
         SchedulingAlgorithmType::kRateMonotonic);
  assert(config.tasks.size() == 2);
}

void TestInvalidExecutionTimeIsRejected() {
  const std::string sim_path = "test_sim_config_invalid.txt";
  const std::string tasks_path = "test_tasks_config_invalid.txt";

  WriteFile(sim_path,
            "simulation_duration_ms=50\n"
            "time_step_ms=1\n"
            "scheduling_algorithm=FIXED_PRIORITY\n"
            "log_output_path=logs/test_log.txt\n"
            "report_output_path=reports/test_report.txt\n");
  // Execution time (100) exceeds deadline (5) -> invalid.
  WriteFile(tasks_path,
            "task_id,period_ms,execution_time_ms,deadline_ms,fixed_priority\n"
            "T1,5,100,5,3\n");

  ConfigurationManager manager(sim_path, tasks_path);
  SimulationConfig config;
  std::string error_message;
  const bool loaded = manager.LoadAndValidate(&config, &error_message);

  assert(!loaded);
  assert(!error_message.empty());
}

}  // namespace

int main() {
  TestValidConfigurationLoads();
  TestInvalidExecutionTimeIsRejected();
  std::cout << "configuration_manager_test: all tests passed." << std::endl;
  return 0;
}
