// GoogleTest suite for DeadlineFaultManager and PerformanceMonitor.
#include <gtest/gtest.h>

#include <memory>
#include <vector>

#include "monitoring/deadline_fault_manager.h"
#include "monitoring/performance_monitor.h"
#include "task/task_instance.h"

namespace {

using automotive_scheduler::DeadlineFaultManager;
using automotive_scheduler::PerformanceMonitor;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskState;

TEST(DeadlineFaultManagerTest, FlagsInstanceOnlyAfterDeadlinePasses) {
  DeadlineFaultManager manager(/*logger=*/nullptr);
  auto instance = std::make_shared<TaskInstance>(
      "T1", 0, /*release_time_ms=*/0, /*execution_time_ms=*/3,
      /*absolute_deadline_ms=*/5, /*priority=*/3);
  instance->set_state(TaskState::kReady);

  manager.CheckDeadlines({instance}, /*current_time_ms=*/4);
  EXPECT_EQ(instance->state(), TaskState::kReady);

  manager.CheckDeadlines({instance}, /*current_time_ms=*/6);
  EXPECT_EQ(instance->state(), TaskState::kDeadlineMissed);
  EXPECT_EQ(manager.deadline_miss_count(), 1);
}

TEST(DeadlineFaultManagerTest, IgnoresAlreadyTerminalInstances) {
  DeadlineFaultManager manager(/*logger=*/nullptr);
  auto completed = std::make_shared<TaskInstance>("T1", 0, 0, 2, 2, 3);
  completed->set_state(TaskState::kCompleted);

  manager.CheckDeadlines({completed}, /*current_time_ms=*/100);
  EXPECT_EQ(completed->state(), TaskState::kCompleted);
  EXPECT_EQ(manager.deadline_miss_count(), 0);
}

TEST(PerformanceMonitorTest, CountsCompletedAndMissedInstances) {
  auto completed = std::make_shared<TaskInstance>("T1", 0, 0, 2, 5, 3);
  completed->set_state(TaskState::kCompleted);
  completed->set_completion_time_ms(2);

  auto missed = std::make_shared<TaskInstance>("T2", 0, 0, 5, 5, 1);
  missed->set_state(TaskState::kDeadlineMissed);

  PerformanceMonitor monitor(/*simulation_duration_ms=*/10,
                              "reports/test_gtest_report.txt");
  monitor.RecordInstances({completed, missed});
  const std::string report = monitor.GenerateReport("Fixed Priority");

  EXPECT_NE(report.find("Completed Tasks       : 1"), std::string::npos);
  EXPECT_NE(report.find("Deadline Misses       : 1"), std::string::npos);
}

}  // namespace
