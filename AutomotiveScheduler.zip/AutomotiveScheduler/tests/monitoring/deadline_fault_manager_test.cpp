// Unit tests for DeadlineFaultManager and PerformanceMonitor.
#include <cassert>
#include <iostream>
#include <memory>
#include <vector>

#include "monitoring/deadline_fault_manager.h"
#include "monitoring/performance_monitor.h"
#include "task/task_instance.h"

namespace {

using automotive_scheduler::DeadlineFaultManager;
using automotive_scheduler::PerformanceMonitor;
using automotive_scheduler::TaskInstance;
using automotive_scheduler::TaskState;

void TestDeadlineMissIsDetected() {
  DeadlineFaultManager manager(/*logger=*/nullptr);
  auto instance = std::make_shared<TaskInstance>("T1", 0, 0, 3,
                                                   /*absolute_deadline_ms=*/5,
                                                   3);
  instance->set_state(TaskState::kReady);

  manager.CheckDeadlines({instance}, /*current_time_ms=*/4);
  assert(instance->state() == TaskState::kReady);

  manager.CheckDeadlines({instance}, /*current_time_ms=*/6);
  assert(instance->state() == TaskState::kDeadlineMissed);
  assert(manager.deadline_miss_count() == 1);
}

void TestPerformanceMonitorCountsCompletedAndMissed() {
  auto completed = std::make_shared<TaskInstance>("T1", 0, 0, 2, 5, 3);
  completed->set_state(TaskState::kCompleted);
  completed->set_completion_time_ms(2);

  auto missed = std::make_shared<TaskInstance>("T2", 0, 0, 5, 5, 1);
  missed->set_state(TaskState::kDeadlineMissed);

  PerformanceMonitor monitor(/*simulation_duration_ms=*/10, "reports/test.txt");
  monitor.RecordInstances({completed, missed});
  const std::string report = monitor.GenerateReport("Fixed Priority");

  assert(report.find("Completed Tasks       : 1") != std::string::npos);
  assert(report.find("Deadline Misses       : 1") != std::string::npos);
}

}  // namespace

int main() {
  TestDeadlineMissIsDetected();
  TestPerformanceMonitorCountsCompletedAndMissed();
  std::cout << "deadline_fault_manager_test: all tests passed." << std::endl;
  return 0;
}
